//
//  MNFCore.h
//  Meniga-ios-sdk
//
//  Created by Haukur Ísfeld on 03/05/2017.
//  Copyright © 2017 Meniga. All rights reserved.
//

#ifndef MNFCore_h
#define MNFCore_h

#import "MNFConstants.h"
#import "MNFObject.h"
#import "MNFAuthenticationProviderProtocol.h"
#import "MNFJsonAdapterDelegate.h"

#endif /* MNFCore_h */
